//función anónima autoejecutable
 (function (d, w, n) {
            'use strict';
        //defino un objeto cuando abro llaves
        var telar1 = {
            nombre : 'Telar Dorothy',
            marcos : 8,
            tipo : ' Telar de mesa ',
            imagen : 'http://1.bp.blogspot.com/_bLzsDx8ImxQ/S8UvsA-J7PI/AAAAAAAACKs/AXzL5OXqmEA/s1600/puntos_telar2.jpg',
            getInfo : function () {
                return '<article><h2>' + this.nombre + '</h2><img src="' + this.imagen + '"><p>' + this.marcos + '</p><p>' + this.tipo + '</p></article>';
            },
            tejer : function (cosa) {
			alert('Voy a tejer ' + cosa);
		},
		    repetir : function (cosa) {
			alert('rapport' + cosa);
		}
        };
            
        console.log(
            telar1,
            telar1.nombre,
            telar1.getInfo()   
        );
            telar1.tejer('tafetan');
            telar1.repetir('tafetán');
    
        //Prototipo Object()
        var telar2 = new Object();
        telar2.nombre = 'Telar de Pedales';
        telar2.marcos = 4;
        telar2.tipo = ' Telar de piso ';
        telar2.imagen = 'https://lh3.googleusercontent.com/-z131vGSy3C4/U0LL_gY2xUI/AAAAAAAAEM0/RX_F-zZ1sN4/s467/telares-de-san-sebastian.jpg';
        telar2.getInfo = function () {
            return '<article><h2>' + this.nombre + '</h2><img src="' + this.imagen + '"><p>' + this.marcos + '</p><p>' + this.tipo + '</p></article>';
        },
        telar2.tejer = function (cosa) {
			alert('Voy a tejer ' + cosa);
		},
        telar2.repetir = function (cosa) {
			alert('rapport' + cosa);
		}
        
        console.log(
            telar2.nombre,
            telar2.marcos,
            telar2.tipo,
            telar2.imagen,
            telar2.getInfo()  
        );
            telar2.tejer('sarga');
            telar2.repetir('sarga');
       
            //Función Constructora
            
        function TelarFunction (nombre, marcos, tipo, imagen) {
            var o = this;
            o.nombre = nombre;
            o.marcos = marcos;
            o.tipo = tipo;
            o.imagen = imagen;
            o.getInfo = function () {
                return '<article><h2>' + o.nombre + '</h2><img src="' + o.imagen + '"><p>' + o.marcos + '</p><p>' + o.tipo + '</p></article>';
            },
            o.tejer = function (cosa) {
			alert('Voy a tejer ' + cosa);
		    },
            o.repetir = function (cosa) {
			alert('rapport' + cosa);
		    }
        }
        
        var telar3 = new TelarFunction('Telar de Pared', 0, 'Telar vertical', 'http://informarse.info/wp-content/uploads/2014/06/telares.jpg');
        
        console.log(
            telar3.nombre,
            telar3.marcos,
            telar3.tipo,
            telar3.imagen,
            telar3.getInfo()  
        );
            telar3.tejer('pata de gallo');
            telar3.repetir('pata de gallo');
        
        //Clases (apartir de ES6 o ES2015)    
        class TelarClass {
            constructor(nombre, marcos, tipo, imagen) {
                this.nombre = nombre;
                this.marcos = marcos;
                this.tipo = tipo;
                this.imagen = imagen;
            }
            getInfo() {//metodo
                return '<article><h2>' + this.nombre + '</h2><img src="' + this.imagen + '"><p>' + this.marcos + '</p><p>' + this.tipo + '</p></article>';
            }
            tejer (cosa) {
                alert('Voy a tejer ' + cosa);  
            }
            repetir (cosa) {
                alert('rapport' + cosa);  
            }   
        }
        var telar4 = new TelarClass('Telar de Cintura', 0, 'Telar tradicional', 'https://s-media-cache-ak0.pinimg.com/736x/32/9f/26/329f2682dcd845137ea1191dc343d774.jpg')
        
         console.log(
            telar4.nombre,
            telar4.marcos,
            telar4.tipo,
            telar4.imagen,
            telar4.getInfo()   
        );
            telar4.tejer('espiriguilla');
            telar4.repetir('espiriguilla');
        
        document.querySelector('.telares').innerHTML = telar1.getInfo() + telar2.getInfo() + telar3.getInfo() + telar4.getInfo();
            
    })(document, window, navigator);
